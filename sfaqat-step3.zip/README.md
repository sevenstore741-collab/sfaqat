Sfaqat - Step 3 (signup, 7-day trial, dashboard)

1. Run supabase/migrations/20261109120300_signup_trial.sql in Supabase SQL Editor (or `npx supabase db push`).
2. Extract this zip over your project root. These paths overwrite existing files:
   src/proxy.ts, messages/ar.json, messages/en.json, src/app/[locale]/page.tsx
3. Supabase > Authentication > URL Configuration: Site URL = http://localhost:3000, Redirect URLs = http://localhost:3000/**
4. For quick testing, turn off "Confirm email" in the Email provider settings (turn it back on before launch).
5. npm run dev
