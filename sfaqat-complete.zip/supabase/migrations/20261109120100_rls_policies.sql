-- =====================================================================
-- Sfaqat - Migration 2: Row Level Security (tenant isolation)
-- IMPORTANT: every table in `public` is exposed through the Supabase Data API,
-- so RLS is enabled on ALL of them. A table with RLS on and no policy is
-- readable/writable only with the secret key (server side).
-- =====================================================================

create or replace function public.is_member(m uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.merchant_members
    where merchant_id = m and user_id = (select auth.uid())
  );
$$;

create or replace function public.is_platform_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.platform_admins
    where id = (select auth.uid()) and is_active
  );
$$;

-- 1) Enable RLS on every table in public
do $$
declare t record;
begin
  for t in select tablename from pg_tables where schemaname = 'public' loop
    execute format('alter table public.%I enable row level security', t.tablename);
  end loop;
end $$;

-- 2) Read access for tenant tables (members of the merchant, or platform admins)
do $$
declare t text;
begin
  foreach t in array array[
    'stores', 'products', 'bots', 'knowledge_items', 'channels', 'customers',
    'conversations', 'messages', 'orders', 'abandoned_carts', 'recovery_attempts',
    'usage_counters', 'daily_stats', 'subscriptions', 'payments'
  ] loop
    execute format(
      'create policy tenant_select on public.%I for select to authenticated
         using (public.is_member(merchant_id) or public.is_platform_admin())', t);
  end loop;
end $$;

-- 3) Merchants & team
create policy merchants_select on public.merchants for select to authenticated
  using (public.is_member(id) or public.is_platform_admin());
create policy merchants_update on public.merchants for update to authenticated
  using (public.is_member(id)) with check (public.is_member(id));

create policy members_select on public.merchant_members for select to authenticated
  using (user_id = (select auth.uid()) or public.is_member(merchant_id) or public.is_platform_admin());

create policy platform_admins_select on public.platform_admins for select to authenticated
  using (id = (select auth.uid()));

-- 4) Plans are public (pricing on the landing page)
create policy plans_select on public.plans for select to anon, authenticated
  using (is_active);

-- 5) Merchants manage their own bot settings and knowledge base
create policy bots_write on public.bots for all to authenticated
  using (public.is_member(merchant_id)) with check (public.is_member(merchant_id));
create policy knowledge_write on public.knowledge_items for all to authenticated
  using (public.is_member(merchant_id)) with check (public.is_member(merchant_id));

-- 6) Catalog child tables (access follows the parent product/store)
create policy product_translations_select on public.product_translations for select to authenticated
  using (exists (
    select 1 from public.products p
    where p.id = product_id and (public.is_member(p.merchant_id) or public.is_platform_admin())
  ));

create policy categories_select on public.categories for select to authenticated
  using (exists (
    select 1 from public.stores s
    where s.id = store_id and (public.is_member(s.merchant_id) or public.is_platform_admin())
  ));

create policy category_translations_select on public.category_translations for select to authenticated
  using (exists (
    select 1 from public.categories c join public.stores s on s.id = c.store_id
    where c.id = category_id and (public.is_member(s.merchant_id) or public.is_platform_admin())
  ));

create policy product_categories_select on public.product_categories for select to authenticated
  using (exists (
    select 1 from public.products p
    where p.id = product_id and (public.is_member(p.merchant_id) or public.is_platform_admin())
  ));

-- 7) Platform-admin-only tables
create policy admin_select on public.system_logs     for select to authenticated using (public.is_platform_admin());
create policy admin_select on public.audit_log       for select to authenticated using (public.is_platform_admin());
create policy admin_select on public.webhook_events  for select to authenticated using (public.is_platform_admin());
create policy admin_select on public.prompt_templates for select to authenticated using (public.is_platform_admin());
create policy admin_select on public.feedback_flags  for select to authenticated using (public.is_platform_admin());

-- 8) store_credentials and channel_credentials: intentionally NO policies (server-only).
-- All writes from the AI engine, webhooks and billing use the secret key (bypasses RLS).
