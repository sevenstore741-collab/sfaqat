-- =====================================================================
-- Sfaqat (صَفَقَات) - Migration 1: schema
-- Supabase / PostgreSQL 15+. Multi-tenant (merchant = tenant), bilingual AR/EN.
-- =====================================================================

create extension if not exists vector  with schema extensions;   -- pgvector (embeddings)
create extension if not exists pg_trgm with schema extensions;   -- fuzzy text search

-- ---------- ENUMS ----------
create type lang_code      as enum ('ar', 'en');
create type platform_type  as enum ('salla', 'zid', 'shopify', 'woocommerce', 'custom');
create type channel_type   as enum ('whatsapp', 'web_widget', 'instagram', 'telegram');
create type sub_status     as enum ('trialing', 'active', 'past_due', 'canceled', 'expired', 'paused');
create type billing_cycle  as enum ('monthly', 'yearly');
create type conv_status    as enum ('open', 'bot_handling', 'handed_to_human', 'closed', 'won', 'lost');
create type msg_role       as enum ('customer', 'bot', 'human_agent', 'system');
create type cart_status    as enum ('abandoned', 'recovering', 'recovered', 'expired', 'opted_out');
create type payment_status as enum ('pending', 'paid', 'failed', 'refunded');
create type admin_role     as enum ('owner', 'support', 'analyst');
create type member_role    as enum ('owner', 'manager', 'agent');
create type log_level      as enum ('debug', 'info', 'warn', 'error', 'critical');

-- ---------- HELPERS ----------
create or replace function public.set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- =====================================================================
-- 1) PLATFORM ADMIN (Super Admin)
-- =====================================================================
create table platform_admins (
  id          uuid primary key references auth.users(id) on delete cascade,
  full_name   text not null,
  role        admin_role not null default 'support',
  is_active   boolean not null default true,
  created_at  timestamptz not null default now()
);

-- =====================================================================
-- 2) MERCHANTS (tenants) & TEAM
-- =====================================================================
create table merchants (
  id                uuid primary key default gen_random_uuid(),
  business_name_ar  text,
  business_name_en  text,
  email             text not null unique,
  phone             text,
  country_code      char(2) not null default 'SA',
  timezone          text not null default 'Asia/Riyadh',
  default_lang      lang_code not null default 'ar',
  is_suspended      boolean not null default false,
  onboarding_step   smallint not null default 0,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);
create trigger trg_merchants_upd before update on merchants
  for each row execute function public.set_updated_at();

create table merchant_members (
  merchant_id  uuid not null references merchants(id) on delete cascade,
  user_id      uuid not null references auth.users(id) on delete cascade,
  role         member_role not null default 'agent',
  created_at   timestamptz not null default now(),
  primary key (merchant_id, user_id)
);
create index on merchant_members(user_id);

-- =====================================================================
-- 3) PLANS, SUBSCRIPTIONS, PAYMENTS (7-day trial built in)
-- =====================================================================
create table plans (
  id               uuid primary key default gen_random_uuid(),
  code             text not null unique,
  name_ar          text not null,
  name_en          text not null,
  price_monthly    numeric(10,2) not null,
  price_yearly     numeric(10,2) not null,
  currency         char(3) not null default 'SAR',
  limits           jsonb not null default '{}',
  features         jsonb not null default '{}',
  is_active        boolean not null default true,
  created_at       timestamptz not null default now()
);

create table subscriptions (
  id                   uuid primary key default gen_random_uuid(),
  merchant_id          uuid not null references merchants(id) on delete cascade,
  plan_id              uuid not null references plans(id),
  status               sub_status not null default 'trialing',
  cycle                billing_cycle not null default 'monthly',
  trial_starts_at      timestamptz default now(),
  trial_ends_at        timestamptz default now() + interval '7 days',
  current_period_start timestamptz,
  current_period_end   timestamptz,
  cancel_at_period_end boolean not null default false,
  gateway              text,
  gateway_customer_id  text,
  gateway_sub_id       text,
  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now()
);
create index on subscriptions(merchant_id);
create index on subscriptions(status, trial_ends_at);
create unique index one_live_sub_per_merchant on subscriptions(merchant_id)
  where status in ('trialing', 'active', 'past_due', 'paused');
create trigger trg_subs_upd before update on subscriptions
  for each row execute function public.set_updated_at();

create table payments (
  id                 uuid primary key default gen_random_uuid(),
  merchant_id        uuid not null references merchants(id) on delete cascade,
  subscription_id    uuid references subscriptions(id) on delete set null,
  amount             numeric(10,2) not null,
  currency           char(3) not null default 'SAR',
  status             payment_status not null default 'pending',
  gateway            text not null,
  gateway_payment_id text,
  invoice_url        text,
  raw_payload        jsonb,
  paid_at            timestamptz,
  created_at         timestamptz not null default now(),
  unique (gateway, gateway_payment_id)
);
create index on payments(merchant_id, created_at desc);

-- =====================================================================
-- 4) STORES (Salla / Zid / others) & CATALOG
-- =====================================================================
create table stores (
  id                uuid primary key default gen_random_uuid(),
  merchant_id       uuid not null references merchants(id) on delete cascade,
  platform          platform_type not null,
  external_store_id text not null,
  name              text,
  domain            text,
  scopes            text[],
  is_connected      boolean not null default true,
  last_synced_at    timestamptz,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  unique (platform, external_store_id)
);
create index on stores(merchant_id);
create trigger trg_stores_upd before update on stores
  for each row execute function public.set_updated_at();

-- Secrets live in their own table: RLS on, NO policies => only the server (secret key) can read them.
-- Values must be encrypted by the application before saving (the *_enc columns hold ciphertext).
create table store_credentials (
  store_id           uuid primary key references stores(id) on delete cascade,
  access_token_enc   text,
  refresh_token_enc  text,
  token_expires_at   timestamptz,
  webhook_secret_enc text,
  updated_at         timestamptz not null default now()
);
create trigger trg_store_credentials_upd before update on store_credentials
  for each row execute function public.set_updated_at();

create table products (
  id            uuid primary key default gen_random_uuid(),
  store_id      uuid not null references stores(id) on delete cascade,
  merchant_id   uuid not null references merchants(id) on delete cascade,
  external_id   text not null,
  sku           text,
  price         numeric(12,2),
  sale_price    numeric(12,2),
  currency      char(3) default 'SAR',
  stock_qty     integer,
  url           text,
  image_url     text,
  is_active     boolean not null default true,
  raw           jsonb,
  updated_at    timestamptz not null default now(),
  unique (store_id, external_id)
);
create index on products(merchant_id);

create table product_translations (
  product_id    uuid not null references products(id) on delete cascade,
  lang          lang_code not null,
  name          text not null,
  description   text,
  embedding     extensions.vector(1536),
  primary key (product_id, lang)
);
create index on product_translations using hnsw (embedding extensions.vector_cosine_ops);
create index on product_translations using gin (name extensions.gin_trgm_ops);

create table categories (
  id           uuid primary key default gen_random_uuid(),
  store_id     uuid not null references stores(id) on delete cascade,
  external_id  text not null,
  parent_id    uuid references categories(id) on delete set null,
  unique (store_id, external_id)
);
create table category_translations (
  category_id uuid not null references categories(id) on delete cascade,
  lang        lang_code not null,
  name        text not null,
  primary key (category_id, lang)
);
create table product_categories (
  product_id  uuid references products(id) on delete cascade,
  category_id uuid references categories(id) on delete cascade,
  primary key (product_id, category_id)
);

-- =====================================================================
-- 5) BOT CONFIG & KNOWLEDGE
-- =====================================================================
create table bots (
  id                    uuid primary key default gen_random_uuid(),
  merchant_id           uuid not null references merchants(id) on delete cascade,
  store_id              uuid references stores(id) on delete set null,
  name                  text not null default 'Sfaqat Bot',
  primary_lang          lang_code not null default 'ar',
  auto_switch_lang      boolean not null default true,
  tone                  text not null default 'friendly_saudi',
  persona_ar            text,
  persona_en            text,
  max_discount_pct      numeric(5,2) not null default 0,
  handoff_keywords      text[] not null default '{}',
  working_hours         jsonb,
  model                 text not null default 'claude-sonnet-5-5',
  system_prompt_version integer not null default 1,
  is_active             boolean not null default true,
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);
create index on bots(merchant_id);
create trigger trg_bots_upd before update on bots
  for each row execute function public.set_updated_at();

create table prompt_templates (
  id           uuid primary key default gen_random_uuid(),
  key          text not null,
  lang         lang_code,
  version      integer not null,
  content      text not null,
  is_active    boolean not null default false,
  created_by   uuid references platform_admins(id),
  created_at   timestamptz not null default now(),
  unique nulls not distinct (key, lang, version)
);

create table knowledge_items (
  id           uuid primary key default gen_random_uuid(),
  merchant_id  uuid not null references merchants(id) on delete cascade,
  bot_id       uuid references bots(id) on delete cascade,
  lang         lang_code not null,
  title        text,
  content      text not null,
  embedding    extensions.vector(1536),
  created_at   timestamptz not null default now()
);
create index on knowledge_items(merchant_id);
create index on knowledge_items using hnsw (embedding extensions.vector_cosine_ops);

create table channels (
  id           uuid primary key default gen_random_uuid(),
  merchant_id  uuid not null references merchants(id) on delete cascade,
  bot_id       uuid not null references bots(id) on delete cascade,
  type         channel_type not null,
  external_id  text,
  config       jsonb not null default '{}',
  is_active    boolean not null default true,
  created_at   timestamptz not null default now(),
  unique (type, external_id)
);
create index on channels(merchant_id);

create table channel_credentials (
  channel_id       uuid primary key references channels(id) on delete cascade,
  credentials_enc  text,
  updated_at       timestamptz not null default now()
);
create trigger trg_channel_credentials_upd before update on channel_credentials
  for each row execute function public.set_updated_at();

-- =====================================================================
-- 6) CUSTOMERS, CONVERSATIONS, MESSAGES
-- =====================================================================
create table customers (
  id                uuid primary key default gen_random_uuid(),
  merchant_id       uuid not null references merchants(id) on delete cascade,
  external_id       text,
  phone             text,
  email             text,
  name              text,
  detected_lang     lang_code,
  marketing_opt_out boolean not null default false,
  created_at        timestamptz not null default now(),
  unique (merchant_id, phone)
);
create index on customers(merchant_id, email);

create table conversations (
  id               uuid primary key default gen_random_uuid(),
  merchant_id      uuid not null references merchants(id) on delete cascade,
  bot_id           uuid not null references bots(id) on delete cascade,
  customer_id      uuid not null references customers(id) on delete cascade,
  channel_id       uuid references channels(id) on delete set null,
  status           conv_status not null default 'bot_handling',
  current_lang     lang_code not null default 'ar',
  summary          text,
  sentiment        smallint,
  started_at       timestamptz not null default now(),
  last_message_at  timestamptz not null default now(),
  closed_at        timestamptz
);
create index on conversations(merchant_id, last_message_at desc);
create index on conversations(customer_id);
create index on conversations(status);

create table messages (
  id               uuid primary key default gen_random_uuid(),
  conversation_id  uuid not null references conversations(id) on delete cascade,
  merchant_id      uuid not null references merchants(id) on delete cascade,
  role             msg_role not null,
  lang             lang_code,
  content          text not null,
  external_msg_id  text,
  tokens_in        integer,
  tokens_out       integer,
  latency_ms       integer,
  tool_calls       jsonb,
  created_at       timestamptz not null default now(),
  unique (conversation_id, external_msg_id)
);
create index on messages(conversation_id, created_at);
create index on messages(merchant_id, created_at desc);

-- =====================================================================
-- 7) SALES: ORDERS, CARTS, RECOVERY
-- =====================================================================
create table orders (
  id                 uuid primary key default gen_random_uuid(),
  merchant_id        uuid not null references merchants(id) on delete cascade,
  store_id           uuid not null references stores(id) on delete cascade,
  customer_id        uuid references customers(id) on delete set null,
  external_order_id  text not null,
  total              numeric(12,2) not null,
  currency           char(3) default 'SAR',
  status             text,
  conversation_id    uuid references conversations(id) on delete set null,
  attributed_to_bot  boolean not null default false,
  placed_at          timestamptz not null,
  raw                jsonb,
  unique (store_id, external_order_id)
);
create index on orders(merchant_id, placed_at desc);

create table abandoned_carts (
  id                 uuid primary key default gen_random_uuid(),
  merchant_id        uuid not null references merchants(id) on delete cascade,
  store_id           uuid not null references stores(id) on delete cascade,
  customer_id        uuid references customers(id) on delete set null,
  external_cart_id   text not null,
  items              jsonb not null,
  total              numeric(12,2),
  checkout_url       text,
  status             cart_status not null default 'abandoned',
  recovered_order_id uuid references orders(id) on delete set null,
  abandoned_at       timestamptz not null default now(),
  recovered_at       timestamptz,
  unique (store_id, external_cart_id)
);
create index on abandoned_carts(merchant_id, status);

create table recovery_attempts (
  id             uuid primary key default gen_random_uuid(),
  cart_id        uuid not null references abandoned_carts(id) on delete cascade,
  merchant_id    uuid not null references merchants(id) on delete cascade,
  attempt_no     smallint not null,
  channel_id     uuid references channels(id) on delete set null,
  lang           lang_code not null,
  message_text   text,
  discount_code  text,
  scheduled_at   timestamptz not null,
  sent_at        timestamptz,
  status         text not null default 'scheduled',
  unique (cart_id, attempt_no)
);
create index on recovery_attempts(status, scheduled_at);

-- =====================================================================
-- 8) ANALYTICS, USAGE, WEBHOOKS, LOGS, AUDIT
-- =====================================================================
create table usage_counters (
  merchant_id   uuid not null references merchants(id) on delete cascade,
  period_start  date not null,
  conversations integer not null default 0,
  messages      integer not null default 0,
  tokens_in     bigint not null default 0,
  tokens_out    bigint not null default 0,
  primary key (merchant_id, period_start)
);

create table daily_stats (
  merchant_id        uuid not null references merchants(id) on delete cascade,
  day                date not null,
  conversations      integer not null default 0,
  bot_resolved       integer not null default 0,
  handoffs           integer not null default 0,
  orders_attributed  integer not null default 0,
  revenue_attributed numeric(14,2) not null default 0,
  carts_recovered    integer not null default 0,
  recovered_revenue  numeric(14,2) not null default 0,
  avg_response_ms    integer,
  primary key (merchant_id, day)
);

create table webhook_events (
  id                uuid primary key default gen_random_uuid(),
  source            text not null,
  event_type        text,
  external_event_id text,
  merchant_id       uuid references merchants(id) on delete set null,
  payload           jsonb not null,
  processed         boolean not null default false,
  error             text,
  received_at       timestamptz not null default now(),
  unique (source, external_event_id)
);
create index on webhook_events(processed, received_at);

create table system_logs (
  id               bigint generated always as identity primary key,
  level            log_level not null,
  service          text not null,
  merchant_id      uuid references merchants(id) on delete set null,
  conversation_id  uuid references conversations(id) on delete set null,
  message          text not null,
  context          jsonb,
  created_at       timestamptz not null default now()
);
create index on system_logs(level, created_at desc);
create index on system_logs(merchant_id, created_at desc);

create table feedback_flags (
  id          uuid primary key default gen_random_uuid(),
  message_id  uuid not null references messages(id) on delete cascade,
  flagged_by  uuid references platform_admins(id),
  reason      text,
  resolved    boolean not null default false,
  created_at  timestamptz not null default now()
);

create table audit_log (
  id          bigint generated always as identity primary key,
  actor_id    uuid,
  actor_type  text,
  action      text not null,
  entity      text,
  entity_id   uuid,
  diff        jsonb,
  created_at  timestamptz not null default now()
);
