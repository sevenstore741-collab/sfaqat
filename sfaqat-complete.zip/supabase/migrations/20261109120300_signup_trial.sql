-- Sfaqat Migration 4: signup trigger (merchant + 7-day trial + default bot) and hardening
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_lang        public.lang_code;
  v_name        text;
  v_merchant_id uuid;
  v_plan_id     uuid;
begin
  v_lang := (case when coalesce(new.raw_user_meta_data ->> 'lang', 'ar') = 'en'
                  then 'en' else 'ar' end)::public.lang_code;
  v_name := left(nullif(btrim(new.raw_user_meta_data ->> 'business_name'), ''), 120);

  -- The 7-day trial runs on the 'pro' plan = all features unlocked
  select id into v_plan_id from public.plans where code = 'pro' and is_active;
  if v_plan_id is null then
    raise exception 'Plan "pro" not found: run the seed plans migration first';
  end if;

  insert into public.merchants (email, business_name_ar, business_name_en, default_lang)
  values (
    new.email,
    case when v_lang = 'ar' then v_name end,
    case when v_lang = 'en' then v_name end,
    v_lang
  )
  returning id into v_merchant_id;

  insert into public.merchant_members (merchant_id, user_id, role)
  values (v_merchant_id, new.id, 'owner');

  insert into public.subscriptions (merchant_id, plan_id, status, trial_starts_at, trial_ends_at)
  values (v_merchant_id, v_plan_id, 'trialing', now(), now() + interval '7 days');

  insert into public.bots (merchant_id, name, primary_lang)
  values (
    v_merchant_id,
    case when v_lang = 'ar' then 'مساعد صفقات' else 'Sfaqat Assistant' end,
    v_lang
  );

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Hardening: merchants may edit only safe columns (not is_suspended, email, ...)
revoke update on public.merchants from authenticated;
grant update (business_name_ar, business_name_en, phone, timezone, default_lang, onboarding_step)
  on public.merchants to authenticated;

-- Bots: merchants edit only their settings (not model / prompt version), cannot create or delete bots
revoke insert, delete, update on public.bots from authenticated;
grant update (name, primary_lang, auto_switch_lang, tone, persona_ar, persona_en,
              max_discount_pct, handoff_keywords, working_hours, is_active)
  on public.bots to authenticated;
