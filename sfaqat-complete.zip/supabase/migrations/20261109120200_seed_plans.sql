-- =====================================================================
-- Sfaqat - Migration 3: seed plans
-- PLACEHOLDER PRICES AND LIMITS: edit before launch. Prices in SAR.
-- Every new merchant starts a 7-day trial with all features (handled at signup).
-- =====================================================================
insert into public.plans (code, name_ar, name_en, price_monthly, price_yearly, limits, features)
values
  ('starter', 'المبتدئ', 'Starter', 99,  990,  '{"stores":1,"conversations":500}'::jsonb,  '{"whatsapp":true,"cart_recovery":false}'::jsonb),
  ('growth',  'النمو',   'Growth',  249, 2490, '{"stores":1,"conversations":2000}'::jsonb, '{"whatsapp":true,"cart_recovery":true}'::jsonb),
  ('pro',     'المحترف', 'Pro',     499, 4990, '{"stores":3,"conversations":10000}'::jsonb,'{"whatsapp":true,"cart_recovery":true}'::jsonb)
on conflict (code) do nothing;
