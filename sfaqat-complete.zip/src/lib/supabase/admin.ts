import { createClient } from "@supabase/supabase-js";

// SERVER ONLY. Uses the secret key and BYPASSES RLS.
// Use for webhooks, the AI engine, and background jobs. Never import this in a Client Component.
export function createAdminClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SECRET_KEY!,
    { auth: { persistSession: false, autoRefreshToken: false } }
  );
}
