import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";

// Temporary connectivity check. Delete this file before going to production.
export async function GET() {
  const supabase = createAdminClient();
  const { data, error } = await supabase.from("plans").select("code").limit(10);

  if (error) {
    return NextResponse.json({ ok: false, error: error.message }, { status: 500 });
  }
  return NextResponse.json({ ok: true, plans: data?.map((p) => p.code) ?? [] });
}
