// Diagnostic: if /api/ping answers "ok", the deployment itself is healthy.
export async function GET() {
  return new Response("ok");
}
