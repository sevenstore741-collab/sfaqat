import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

// Handles the confirmation link sent by email
export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const next = searchParams.get("next") ?? "/ar/dashboard";
  const safeNext =
    next.startsWith("/") && !next.startsWith("//") ? next : "/ar/dashboard";

  if (code) {
    const supabase = await createClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);
    if (!error) return NextResponse.redirect(`${origin}${safeNext}`);
  }
  return NextResponse.redirect(`${origin}/ar/login`);
}
