import { getTranslations, setRequestLocale } from "next-intl/server";
import { redirect } from "@/i18n/navigation";
import { createClient } from "@/lib/supabase/server";
import { getDaysLeft } from "@/lib/trial";
import LocaleSwitcher from "@/components/LocaleSwitcher";
import SignOutButton from "@/components/SignOutButton";
import BotLanguageForm from "@/components/BotLanguageForm";

export default async function DashboardPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  setRequestLocale(locale);
  const t = await getTranslations("Dashboard");

  const supabase = await createClient();
  const { data: userData } = await supabase.auth.getUser();
  const user = userData.user;
  if (!user) return redirect({ href: "/login", locale });

  const { data: membership } = await supabase
    .from("merchant_members")
    .select("merchant_id")
    .eq("user_id", user.id)
    .limit(1)
    .maybeSingle();

  if (!membership) {
    return (
      <main className="mx-auto flex min-h-screen max-w-md items-center justify-center px-6 text-center">
        <p className="text-muted">{t("noMerchant")}</p>
      </main>
    );
  }

  const merchantId = membership.merchant_id as string;

  const [merchantRes, subRes, botRes, convRes, ordersRes, recoveredRes] =
    await Promise.all([
      supabase
        .from("merchants")
        .select("business_name_ar, business_name_en")
        .eq("id", merchantId)
        .maybeSingle(),
      supabase
        .from("subscriptions")
        .select("status, trial_ends_at, plan_id")
        .eq("merchant_id", merchantId)
        .limit(1)
        .maybeSingle(),
      supabase
        .from("bots")
        .select("id, primary_lang")
        .eq("merchant_id", merchantId)
        .limit(1)
        .maybeSingle(),
      supabase
        .from("conversations")
        .select("id", { count: "exact", head: true })
        .eq("merchant_id", merchantId),
      supabase
        .from("orders")
        .select("id", { count: "exact", head: true })
        .eq("merchant_id", merchantId)
        .eq("attributed_to_bot", true),
      supabase
        .from("abandoned_carts")
        .select("id", { count: "exact", head: true })
        .eq("merchant_id", merchantId)
        .eq("status", "recovered"),
    ]);

  const merchant = merchantRes.data;
  const sub = subRes.data;
  const bot = botRes.data;

  const { data: plan } = sub
    ? await supabase
        .from("plans")
        .select("name_ar, name_en")
        .eq("id", sub.plan_id)
        .maybeSingle()
    : { data: null };

  const displayName =
    (locale === "ar"
      ? merchant?.business_name_ar ?? merchant?.business_name_en
      : merchant?.business_name_en ?? merchant?.business_name_ar) ??
    user.email ??
    "";

  const planName = plan ? (locale === "ar" ? plan.name_ar : plan.name_en) : "";
  const isTrial = sub?.status === "trialing";
  const daysLeft = isTrial ? getDaysLeft(sub?.trial_ends_at ?? null) : 0;
  const progress = Math.min(100, Math.max(0, ((7 - daysLeft) / 7) * 100));

  const stats = [
    { label: t("statConversations"), value: convRes.count ?? 0 },
    { label: t("statBotOrders"), value: ordersRes.count ?? 0 },
    { label: t("statRecovered"), value: recoveredRes.count ?? 0 },
  ];

  const steps = [
    { label: t("step1"), soon: true },
    { label: t("step2"), soon: false },
    { label: t("step3"), soon: true },
  ];

  return (
    <div className="mx-auto min-h-screen max-w-4xl px-6 py-6">
      <header className="mb-8 flex items-center justify-between gap-3">
        <span className="text-xl font-bold">
          {locale === "ar" ? "صَفَقَات" : "Sfaqat"}
        </span>
        <div className="flex items-center gap-2">
          <LocaleSwitcher />
          <SignOutButton />
        </div>
      </header>

      <h1 className="mb-1 text-3xl font-bold">{t("welcome", { name: displayName })}</h1>
      <p className="mb-8 text-muted">{t("title")}</p>

      <section className="mb-6 rounded-2xl border border-border bg-card p-5">
        <div className="mb-3 flex items-center justify-between gap-3">
          <h2 className="font-semibold">{t("trialTitle")}</h2>
          {sub && (
            <span className="rounded-full border border-border px-3 py-0.5 text-xs text-muted">
              {t(`status.${sub.status}`)}
            </span>
          )}
        </div>
        {isTrial ? (
          <>
            <p className="mb-3 text-lg">{t("trialDays", { days: daysLeft })}</p>
            <div className="mb-3 h-2 overflow-hidden rounded-full bg-background">
              <div className="h-full bg-primary" style={{ width: `${progress}%` }} />
            </div>
            <p className="text-sm text-muted">{t("trialNote")}</p>
          </>
        ) : null}
        {planName && <p className="mt-2 text-sm text-muted">{t("plan", { plan: planName })}</p>}
      </section>

      <section className="mb-6">
        <h2 className="mb-3 font-semibold">{t("statsTitle")}</h2>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          {stats.map((s) => (
            <div key={s.label} className="rounded-2xl border border-border bg-card p-5">
              <p className="text-sm text-muted">{s.label}</p>
              <p className="mt-1 text-3xl font-bold">{s.value}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mb-6 rounded-2xl border border-border bg-card p-5">
        <h2 className="mb-3 font-semibold">{t("stepsTitle")}</h2>
        <ol className="flex flex-col gap-2">
          {steps.map((s, i) => (
            <li
              key={s.label}
              className="flex items-center justify-between gap-3 rounded-lg border border-border bg-background px-3 py-2"
            >
              <span>
                {i + 1}. {s.label}
              </span>
              {s.soon && <span className="text-xs text-muted">{t("soon")}</span>}
            </li>
          ))}
        </ol>
      </section>

      {bot && (
        <section className="rounded-2xl border border-border bg-card p-5">
          <h2 className="mb-1 font-semibold">{t("botLangTitle")}</h2>
          <p className="mb-4 text-sm text-muted">{t("botLangHint")}</p>
          <BotLanguageForm
            botId={bot.id as string}
            initial={bot.primary_lang === "en" ? "en" : "ar"}
          />
        </section>
      )}
    </div>
  );
}
