import { getTranslations, setRequestLocale } from "next-intl/server";
import { Link } from "@/i18n/navigation";
import SignupForm from "@/components/SignupForm";
import LocaleSwitcher from "@/components/LocaleSwitcher";

export default async function SignupPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  setRequestLocale(locale);
  const t = await getTranslations("Auth");

  return (
    <main className="relative mx-auto flex min-h-screen max-w-md flex-col justify-center gap-6 px-6">
      <div className="absolute top-4 end-4">
        <LocaleSwitcher />
      </div>
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-bold">{t("signupTitle")}</h1>
        <p className="text-muted">{t("signupSubtitle")}</p>
      </div>
      <div className="rounded-2xl border border-border bg-card p-6">
        <SignupForm />
      </div>
      <p className="text-center text-sm text-muted">
        {t("haveAccount")}{" "}
        <Link href="/login" className="text-primary">
          {t("goLogin")}
        </Link>
      </p>
    </main>
  );
}
