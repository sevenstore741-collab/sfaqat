import { getTranslations, setRequestLocale } from "next-intl/server";
import { Link } from "@/i18n/navigation";
import LoginForm from "@/components/LoginForm";
import LocaleSwitcher from "@/components/LocaleSwitcher";

export default async function LoginPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  setRequestLocale(locale);
  const t = await getTranslations("Auth");

  return (
    <main className="relative mx-auto flex min-h-screen max-w-md flex-col justify-center gap-6 px-6">
      <div className="absolute top-4 end-4">
        <LocaleSwitcher />
      </div>
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-bold">{t("loginTitle")}</h1>
        <p className="text-muted">{t("loginSubtitle")}</p>
      </div>
      <div className="rounded-2xl border border-border bg-card p-6">
        <LoginForm />
      </div>
      <p className="text-center text-sm text-muted">
        {t("noAccount")}{" "}
        <Link href="/signup" className="text-primary">
          {t("goSignup")}
        </Link>
      </p>
    </main>
  );
}
